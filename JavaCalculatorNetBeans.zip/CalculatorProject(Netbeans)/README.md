# Ora’s Calculator

Ora’s Calculator is a feature-rich scientific calculator developed as a Java NetBeans project. 
Built as a school project, it goes beyond basic arithmetic by supporting a wide range of advanced mathematical operations.

## Project Structure
This is a multi-file Java project developed in NetBeans, following proper separation of concerns:
- UI components are handled separately from calculation logic
- Button actions and mathematical operations are modularized across multiple classes

## Features
- Basic arithmetic (+, −, ×, ÷)
- Trigonometric functions (sin, cos, tan)
- Hyperbolic functions (sinh, cosh, tanh)
- Exponential and logarithmic operations
- Powers and roots (x², x³, xʸ, √x)
- Factorial and reciprocal calculations
- Percentage operations
- Clear (C) and All Clear (AC) controls
- Sign toggle (+/−)
- Graphical user interface

## User Experience Considerations
- Visual feedback is used to clearly indicate invalid operations or errors
- Error states are immediately noticeable through display color changes 


## Technologies Used
- Java
- NetBeans IDE
- Swing

## How to Run
1. Clone or download the repository
2. Open the project in NetBeans
3. Build the project
4. Run the main class to launch the calculator


## Purpose
The goal of this project was to apply Java programming fundamentals, mathematical logic, and GUI design principles in a structured, multi-class application.

## License
Licensed under the MIT License.

## Author
Oarabile Maloka